
-- --------------------------------------------------------

--
-- Table structure for table `tax_groups`
--

CREATE TABLE `tax_groups` (
  `id` int(11) NOT NULL,
  `tax_group_name` varchar(150) DEFAULT NULL,
  `tax_group_archive` smallint(6) DEFAULT '0',
  `tax_group_code` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tax_groups`
--

INSERT INTO `tax_groups` (`id`, `tax_group_name`, `tax_group_archive`, `tax_group_code`, `created_at`, `updated_at`) VALUES
(3, 'Computers', 1, 'PC080100', NULL, NULL),
(10, 'General Sales', 1, 'O9999999', NULL, NULL),
(14, 'Clothing', 1, 'PC030100', NULL, NULL),
(15, 'Wholesale', 0, 'whsl', NULL, NULL);
