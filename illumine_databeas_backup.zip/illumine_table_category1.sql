
-- --------------------------------------------------------

--
-- Table structure for table `category1`
--

CREATE TABLE `category1` (
  `id` int(11) NOT NULL,
  `name` varchar(75) DEFAULT NULL,
  `is_archive` smallint(6) DEFAULT '0',
  `sort` float(11,3) DEFAULT '1.000',
  `description` text,
  `nav` smallint(6) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `category1`
--

INSERT INTO `category1` (`id`, `name`, `is_archive`, `sort`, `description`, `nav`, `created_at`, `updated_at`) VALUES
(10, 'Embellished Cards', 0, 2.000, 'Embellished Spiritual Greeting Cards', 1, NULL, NULL),
(11, 'Embellished Prints', 0, 4.000, 'Embellished Spiritual Prints', 1, NULL, NULL),
(12, 'Plain Cards', 0, 1.000, 'Spiritual Greeting Cards', 1, NULL, NULL),
(13, 'Plain Prints', 0, 3.000, 'Spiritual Prints', 1, NULL, NULL),
(15, 'Featured Item 1', 0, 6.000, 'Featured Spiritual Greeting Card', 0, NULL, NULL),
(16, 'Featured Item 2', 0, 7.000, 'Featured Embellished Greeting Card', 0, NULL, NULL),
(17, 'Featured Item 3', 0, 8.000, 'Featured Spiritual Print', 0, NULL, NULL),
(75, 'Candles', 0, 0.000, 'Sacred image on a 3 X 6 white wax pillar.', 1, NULL, NULL);
