
-- --------------------------------------------------------

--
-- Table structure for table `discount_apply_types`
--

CREATE TABLE `discount_apply_types` (
  `discount_apply_type_id` int(11) NOT NULL,
  `discount_apply_type_description` varchar(100) NOT NULL,
  `discount_apply_type_archive` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_apply_types`
--

INSERT INTO `discount_apply_types` (`discount_apply_type_id`, `discount_apply_type_description`, `discount_apply_type_archive`, `created_at`, `updated_at`) VALUES
(1, 'Purchase', 0, NULL, NULL);
