
-- --------------------------------------------------------

--
-- Table structure for table `config_groups`
--

CREATE TABLE `config_groups` (
  `id` int(11) NOT NULL,
  `config_group_name` varchar(50) DEFAULT NULL,
  `config_group_sort` float(11,3) DEFAULT '1.000',
  `config_group_show_merchant` tinyint(4) DEFAULT '0',
  `config_group_protected` tinyint(4) DEFAULT '1',
  `config_group_description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `config_groups`
--

INSERT INTO `config_groups` (`id`, `config_group_name`, `config_group_sort`, `config_group_show_merchant`, `config_group_protected`, `config_group_description`, `created_at`, `updated_at`) VALUES
(3, 'Company Info.', 1.000, 1, 1, 'Enter global settings for company information.', NULL, NULL),
(5, 'Tax Settings', 1.000, 1, 1, 'Manage global tax system settings.', NULL, NULL),
(6, 'Shipping Settings', 1.000, 1, 1, 'Manage global shipping system settings.', NULL, NULL),
(7, 'Admin Controls', 1.000, 0, 1, 'Manage global settings for the admin interface.', NULL, NULL),
(8, 'Product Display', 1.000, 0, 1, 'Manage global settings for front end display.', NULL, NULL),
(10, 'Debug Settings', 1.000, 0, 1, 'Select the variable scopes to be shown as part of the debugging output. <br> Warning: Enabling all scopes may cause timeout errors, depending on your server settings.', NULL, NULL),
(11, 'Discount Settings', 1.000, 1, 1, 'Manage global settings for discount system.', NULL, NULL),
(24, 'Product Admin Settings', 1.000, 0, 1, 'Manage global settings related to product administration.', NULL, NULL),
(25, 'Global Settings', 1.000, 0, 1, 'Manage application global settings', NULL, NULL),
(27, 'Email Settings', 1.000, 0, 1, 'Sitewide email options and message content    (<a href=\"email-sample.cfm\" target=\"_blank\">View sample email format</a>)', NULL, NULL),
(29, 'Customer Settings', 1.000, 0, 1, 'Manage options related to customer accounts', NULL, NULL),
(9, 'Payment Settings', 1.000, 0, 1, 'Manage payment settings and options', NULL, NULL),
(12, 'Cart Pages', 1.000, 0, 1, 'Manage default pages for Cartweaver functions', NULL, NULL),
(13, 'Cart Display Settings', 1.000, 0, 1, 'Manage display settings for general cart functions', NULL, NULL),
(14, 'Image Settings', 1.000, 0, 1, 'Manage global options for product images', NULL, NULL),
(15, 'Admin Home', 1.000, 0, 1, 'Manage content on admin landing page', NULL, NULL),
(30, 'Developer Settings', 1.000, 0, 1, 'Manage developer-only options', NULL, NULL),
(31, 'Download Settings', 1.000, 0, 1, 'Manage global options for file downloads', NULL, NULL);
