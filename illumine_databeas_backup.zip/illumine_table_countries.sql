
-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(11) NOT NULL,
  `country_name` varchar(50) DEFAULT NULL,
  `country_code` varchar(50) DEFAULT NULL,
  `country_sort` float(11,3) DEFAULT '1.000',
  `country_archive` smallint(6) DEFAULT '0',
  `country_default_country` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `country_name`, `country_code`, `country_sort`, `country_archive`, `country_default_country`, `created_at`, `updated_at`) VALUES
(1, 'United States', 'US', 1.000, 0, 1, NULL, NULL),
(7, 'Belgium', 'BEL', 9.000, 0, 0, NULL, NULL),
(21, 'Argentina', 'AR', 9.000, 0, 0, NULL, NULL),
(23, 'Australia', 'AU', 1.000, 0, 0, NULL, NULL),
(38, 'Brazil', 'BR', 9.000, 0, 0, NULL, NULL),
(45, 'Canada', 'CA', 1.000, 0, 0, NULL, NULL),
(51, 'China', 'CN', 9.000, 0, 0, NULL, NULL),
(75, 'France', 'FR', 1.000, 0, 0, NULL, NULL),
(80, 'Germany', 'DE', 9.000, 0, 0, NULL, NULL),
(96, 'Ireland', 'IE', 9.000, 0, 0, NULL, NULL),
(97, 'Israel', 'IL', 9.000, 0, 0, NULL, NULL),
(98, 'Italy', 'IT', 9.000, 0, 0, NULL, NULL),
(100, 'Japan', 'JP', 1.000, 0, 0, NULL, NULL),
(127, 'Mexico', 'MX', 1.000, 0, 0, NULL, NULL),
(139, 'New Zealand', 'NZ', 1.000, 0, 0, NULL, NULL),
(175, 'Spain', 'ES', 9.000, 0, 0, NULL, NULL),
(198, 'United Kingdom', 'GB', 1.000, 0, 0, NULL, NULL);
