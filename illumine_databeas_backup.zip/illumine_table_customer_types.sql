
-- --------------------------------------------------------

--
-- Table structure for table `customer_types`
--

CREATE TABLE `customer_types` (
  `id` int(11) NOT NULL,
  `customer_type_name` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `customer_types`
--

INSERT INTO `customer_types` (`id`, `customer_type_name`, `created_at`, `updated_at`) VALUES
(1, 'Retail', NULL, NULL),
(2, 'Wholesale', NULL, NULL);
