
-- --------------------------------------------------------

--
-- Table structure for table `customers_imports`
--

CREATE TABLE `customers_imports` (
  `id` varchar(50) NOT NULL,
  `type_id` int(11) DEFAULT NULL,
  `First_name` varchar(255) DEFAULT NULL,
  `Last_name` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Company` varchar(255) DEFAULT NULL,
  `Address1` varchar(255) DEFAULT NULL,
  `Address2` varchar(255) DEFAULT NULL,
  `City` varchar(255) DEFAULT NULL,
  `Zip` varchar(255) DEFAULT NULL,
  `Province` varchar(255) DEFAULT NULL,
  `Province Code` varchar(255) DEFAULT NULL,
  `Country` varchar(255) DEFAULT NULL,
  `Country Code` varchar(255) DEFAULT NULL,
  `Accepts Marketing` tinyint(1) DEFAULT NULL,
  `Phone` varchar(255) DEFAULT NULL,
  `Phone_mobile` varchar(255) DEFAULT NULL,
  `Guest` tinyint(1) DEFAULT NULL,
  `Tags` varchar(255) DEFAULT NULL,
  `Note` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
