
-- --------------------------------------------------------

--
-- Table structure for table `option_types`
--

CREATE TABLE `option_types` (
  `id` int(11) NOT NULL,
  `optiontype_required` tinyint(4) DEFAULT '1',
  `optiontype_name` varchar(75) DEFAULT NULL,
  `optiontype_archive` smallint(6) DEFAULT '0',
  `optiontype_deleted` smallint(1) DEFAULT '0',
  `optiontype_sort` float(11,3) DEFAULT '1.000',
  `optiontype_text` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `option_types`
--

INSERT INTO `option_types` (`id`, `optiontype_required`, `optiontype_name`, `optiontype_archive`, `optiontype_deleted`, `optiontype_sort`, `optiontype_text`, `created_at`, `updated_at`) VALUES
(1, 1, 'Card', 0, 0, 1.000, NULL, NULL, NULL),
(2, 1, 'Print', 0, 0, 2.000, '', NULL, NULL);
