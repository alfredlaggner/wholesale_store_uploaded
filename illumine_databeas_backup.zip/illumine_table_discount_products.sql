
-- --------------------------------------------------------

--
-- Table structure for table `discount_products`
--

CREATE TABLE `discount_products` (
  `id` int(11) NOT NULL,
  `discount2product_discount_id` int(11) NOT NULL DEFAULT '0',
  `discount2product_product_id` int(11) NOT NULL DEFAULT '0',
  `discount_product_active` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_products`
--

INSERT INTO `discount_products` (`id`, `discount2product_discount_id`, `discount2product_product_id`, `discount_product_active`, `created_at`, `updated_at`) VALUES
(50, 73, 94, 1, NULL, NULL),
(49, 73, 103, 1, NULL, NULL),
(48, 73, 104, 1, NULL, NULL),
(47, 73, 95, 1, NULL, NULL),
(46, 73, 109, 1, NULL, NULL),
(45, 73, 105, 1, NULL, NULL),
(44, 73, 99, 1, NULL, NULL),
(51, 73, 100, 1, NULL, NULL),
(70, 78, 109, 1, NULL, NULL),
(53, 73, 96, 1, NULL, NULL),
(54, 73, 101, 1, NULL, NULL),
(56, 73, 108, 1, NULL, NULL),
(57, 73, 93, 1, NULL, NULL),
(58, 73, 112, 1, NULL, NULL),
(71, 78, 111, 1, NULL, NULL),
(72, 78, 110, 1, NULL, NULL),
(73, 78, 112, 1, NULL, NULL),
(74, 78, 103, 1, NULL, NULL),
(75, 82, 103, 1, NULL, NULL);
