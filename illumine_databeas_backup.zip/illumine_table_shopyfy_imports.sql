
-- --------------------------------------------------------

--
-- Table structure for table `shopyfy_imports`
--

CREATE TABLE `shopyfy_imports` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_id` int(11) NOT NULL,
  `Handle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Vendor` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Tags` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Published` tinyint(1) NOT NULL,
  `Option1 Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Option1 Value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Option2 Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Option2 Value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Option3 Name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Option3 Value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant SKU` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Grams` int(11) NOT NULL,
  `Variant Inventory Tracker` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Inventory Quantity` int(11) NOT NULL,
  `Variant Inventory Policy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Fulfillment Service` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Price` double(8,2) NOT NULL,
  `Variant Compare at Price` double(8,2) NOT NULL,
  `Variant Requires Shipping` tinyint(1) NOT NULL,
  `Variant Taxable` tinyint(1) NOT NULL,
  `Variant Barcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image Src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Image Position` int(11) NOT NULL,
  `Image Alt Text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Gift Card` tinyint(1) NOT NULL,
  `Variant Image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Weight Unit` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Variant Tax Code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SEO Title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SEO Description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
