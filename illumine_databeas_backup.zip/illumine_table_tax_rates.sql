
-- --------------------------------------------------------

--
-- Table structure for table `tax_rates`
--

CREATE TABLE `tax_rates` (
  `id` int(11) NOT NULL,
  `tax_rate_region_id` int(11) DEFAULT '0',
  `tax_rate_group_id` int(11) DEFAULT '0',
  `tax_rate_percentage` double DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tax_rates`
--

INSERT INTO `tax_rates` (`id`, `tax_rate_region_id`, `tax_rate_group_id`, `tax_rate_percentage`, `created_at`, `updated_at`) VALUES
(10, 5, 2, 8, NULL, NULL),
(13, 7, 5, 0, NULL, NULL),
(29, 8, 5, 12.345, NULL, NULL),
(21, 7, 3, 17.2, NULL, NULL),
(26, 2, 5, 10, NULL, NULL),
(31, 6, 9, 17.5, NULL, NULL),
(33, 1, 10, 10, NULL, NULL),
(35, 12, 10, 20, NULL, NULL),
(36, 1, 15, 0, NULL, NULL),
(37, 1, 15, 0, NULL, NULL);
