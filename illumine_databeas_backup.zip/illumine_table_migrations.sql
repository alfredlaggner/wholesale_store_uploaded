
-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2017_11_06_053128_admin_users', 1),
(4, '2017_11_06_053639_admin_users_add_timestamp', 1),
(5, '2017_11_06_054254_categories_primaries_add_timestamp', 2),
(6, '2017_11_06_054425_categories_secondaries_add_timestamp', 2),
(7, '2017_11_06_054654_config_groups_add_timestamp', 2),
(8, '2017_11_06_054809_config_items_add_timestamp', 2),
(9, '2017_11_06_054913_countries_add_timestamp', 2),
(10, '2017_11_06_055025_credit_cards_add_timestamp', 2),
(11, '2017_11_06_055139_customers_add_timestamp', 2),
(12, '2017_11_06_055313_customer_stateprov_add_timestamp', 2),
(13, '2017_11_06_055436_customer_types_add_timestamp', 2),
(14, '2017_11_06_060926_discounts_add_timestamp', 2),
(15, '2017_11_06_063617_xcreate_discounts_table', 2),
(16, '2017_11_06_063952_create_discounts_table', 2),
(17, '2017_11_06_150941_create_discount_amounts_table', 2),
(18, '2017_11_06_151222_xxcreate_discount_amounts_table', 2),
(19, '2017_11_06_153424_create_discount_apply_types_table', 2),
(20, '2017_11_06_153610_create_discount_categories_table', 2),
(21, '2017_11_06_153906_create_discount_products_table', 2),
(22, '2017_11_06_154128_create_discount_skuses_table', 3),
(23, '2017_11_06_154333_create_discount_types_table', 3),
(24, '2017_11_06_154512_create_discount_usages_table', 4),
(25, '2017_11_06_154646_create_downloads_table', 4),
(26, '2017_11_06_154755_create_image_types_table', 4),
(27, '2017_11_06_155000_create_options_table', 4),
(28, '2017_11_06_155118_create_option_types_table', 4),
(29, '2017_11_06_155242_create_orders_table', 4),
(30, '2017_11_06_155422_create_order_payments_table', 4),
(31, '2017_11_06_155614_create_order_skuses_table', 5),
(32, '2017_11_06_155733_create_order_sku_datas_table', 5),
(33, '2017_11_06_155835_create_order_statuses_table', 5),
(34, '2017_11_06_182953_create_product_primary_categories_table', 5),
(35, '2017_11_06_183135_create_product_secundary_categories_table', 6),
(36, '2017_11_06_183241_create_product_images_table', 6),
(37, '2017_11_06_183409_create_product_options_table', 6),
(38, '2017_11_06_183502_create_product_upsells_table', 6),
(39, '2017_11_06_183612_create_ship_methods_table', 6),
(40, '2017_11_06_183757_create_ship_method_countries_table', 6),
(41, '2017_11_06_183932_create_ship_ranges_table', 6),
(42, '2017_11_06_184245_create_skuses_table', 7),
(43, '2017_11_06_184417_create_sku_options_table', 7),
(44, '2017_11_06_184512_create_stateprovs_table', 8),
(45, '2017_11_06_185538_create_tax_groups_table', 8),
(46, '2017_11_06_185626_create_tax_rates_table', 8),
(47, '2017_11_06_185724_create_tax_regions_table', 8),
(48, '2017_11_06_190822_create_categories_primaries_table', 8),
(49, '2017_11_06_190952_create_categories_secundaries_table', 8),
(50, '2017_11_26_185930_add_timestamp_category1_product', 9),
(51, '2017_11_26_224451_add_timestamp_product', 10),
(52, '2017_11_26_233957_add_timestamp_product2', 11),
(53, '2017_12_02_165623_create_shopify_upload', 12),
(54, '2017_12_02_212308_shopify_upload_add_nullable', 13),
(55, '2017_12_03_134357_create_shopify_import2', 14),
(56, '2017_12_06_025535_add_collection_to_shopify_import', 15);
