
-- --------------------------------------------------------

--
-- Table structure for table `discount_categories`
--

CREATE TABLE `discount_categories` (
  `id` int(11) NOT NULL,
  `discount2category_discount_id` int(11) NOT NULL DEFAULT '0',
  `discount2category_category_id` int(11) NOT NULL DEFAULT '0',
  `discount_category_type` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_categories`
--

INSERT INTO `discount_categories` (`id`, `discount2category_discount_id`, `discount2category_category_id`, `discount_category_type`, `created_at`, `updated_at`) VALUES
(125, 72, 79, 2, NULL, NULL),
(116, 70, 73, 2, NULL, NULL),
(112, 70, 80, 2, NULL, NULL),
(121, 65, 73, 2, NULL, NULL);
