
--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_users`
--
ALTER TABLE `admin_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cart_custcart_id_idx` (`cart_custcart_id`),
  ADD KEY `cart_sku_id_idx` (`cart_sku_id`),
  ADD KEY `cart_sku_unique_id_idx` (`cart_sku_unique_id`);

--
-- Indexes for table `category1`
--
ALTER TABLE `category1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category1_product`
--
ALTER TABLE `category1_product`
  ADD KEY `product2category_product_id_idx` (`product_id`),
  ADD KEY `product2category_category_id_idx` (`category1_id`);

--
-- Indexes for table `category2`
--
ALTER TABLE `category2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category2_product`
--
ALTER TABLE `category2_product`
  ADD KEY `product2secondary_product_id_idx` (`product_id`),
  ADD KEY `product2secondary_secondary_id_idx` (`category2_id`);

--
-- Indexes for table `config_groups`
--
ALTER TABLE `config_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_items`
--
ALTER TABLE `config_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_group_id_idx` (`config_group_id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `credit_cards`
--
ALTER TABLE `credit_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_type_id_idx` (`type_id`);

--
-- Indexes for table `customers_imports`
--
ALTER TABLE `customers_imports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_type_id_idx` (`type_id`);

--
-- Indexes for table `customer_stateproves`
--
ALTER TABLE `customer_stateproves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_state_customer_id_idx` (`customer_state_customer_id`),
  ADD KEY `customer_state_stateprov_id_idx` (`customer_state_stateprov_id`);

--
-- Indexes for table `customer_types`
--
ALTER TABLE `customer_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cw_products`
--
ALTER TABLE `cw_products`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `product_tax_group_id_idx` (`product_tax_group_id`);

--
-- Indexes for table `discounts`
--
ALTER TABLE `discounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_amounts`
--
ALTER TABLE `discount_amounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discount_amount_discount_id_idx` (`discount_amount_discount_id`);

--
-- Indexes for table `discount_apply_types`
--
ALTER TABLE `discount_apply_types`
  ADD PRIMARY KEY (`discount_apply_type_id`);

--
-- Indexes for table `discount_categories`
--
ALTER TABLE `discount_categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discount2category_discount_id_idx` (`discount2category_discount_id`),
  ADD KEY `discount2category_category_id_idx` (`discount2category_category_id`);

--
-- Indexes for table `discount_products`
--
ALTER TABLE `discount_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discount2product_discount_id_idx` (`discount2product_discount_id`),
  ADD KEY `discount2product_product_id_idx` (`discount2product_product_id`);

--
-- Indexes for table `discount_skuses`
--
ALTER TABLE `discount_skuses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discount2sku_discount_id_idx` (`discount2sku_discount_id`),
  ADD KEY `discount2sku_sku_id_idx` (`discount2sku_sku_id`);

--
-- Indexes for table `discount_types`
--
ALTER TABLE `discount_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_usages`
--
ALTER TABLE `discount_usages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `discount_usage_order_id_idx` (`discount_usage_order_id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `dl_sku_id_idx` (`dl_sku_id`),
  ADD KEY `dl_customer_id_idx` (`dl_customer_id`);

--
-- Indexes for table `image_types`
--
ALTER TABLE `image_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `option_type_id_idx` (`option_type_id`);

--
-- Indexes for table `option_types`
--
ALTER TABLE `option_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_customer_id_idx` (`order_customer_id`);

--
-- Indexes for table `order_payments`
--
ALTER TABLE `order_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id_idx` (`order_id`);

--
-- Indexes for table `order_skuses`
--
ALTER TABLE `order_skuses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ordersku_order_id_idx` (`ordersku_order_id`),
  ADD KEY `ordersku_unique_id_idx` (`ordersku_unique_id`);

--
-- Indexes for table `order_sku_datas`
--
ALTER TABLE `order_sku_datas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `data_sku_id_idx` (`data_sku_id`),
  ADD KEY `data_cart_id_idx` (`data_cart_id`);

--
-- Indexes for table `order_statuses`
--
ALTER TABLE `order_statuses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tax_group_id_idx` (`tax_group_id`) USING BTREE;

--
-- Indexes for table `products2`
--
ALTER TABLE `products2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tax_group_id_idx` (`tax_group_id`) USING BTREE;

--
-- Indexes for table `products_broken`
--
ALTER TABLE `products_broken`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tax_group_id_idx` (`tax_group_id`);

--
-- Indexes for table `products_no_cr`
--
ALTER TABLE `products_no_cr`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_tax_group_id_idx` (`tax_group_id`) USING BTREE;

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_image_product_id_idx` (`product_id`),
  ADD KEY `product_image_imagetype_id_idx` (`imagetype_id`);

--
-- Indexes for table `product_options`
--
ALTER TABLE `product_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_options2prod_id_idx` (`product_options2prod_id`),
  ADD KEY `product_options2optiontype_id_idx` (`product_options2optiontype_id`);

--
-- Indexes for table `product_upsells`
--
ALTER TABLE `product_upsells`
  ADD PRIMARY KEY (`id`),
  ADD KEY `upsell_product_id_idx` (`upsell_product_id`),
  ADD KEY `upsell_2product_id_idx` (`upsell_2product_id`);

--
-- Indexes for table `ship_methods`
--
ALTER TABLE `ship_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ship_method_countries`
--
ALTER TABLE `ship_method_countries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ship_method_country_method_id_idx` (`ship_method_country_method_id`),
  ADD KEY `ship_method_country_country_id_idx` (`ship_method_country_country_id`);

--
-- Indexes for table `ship_ranges`
--
ALTER TABLE `ship_ranges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ship_range_method_id_idx` (`ship_range_method_id`);

--
-- Indexes for table `shopify_imports`
--
ALTER TABLE `shopify_imports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopyfy_imports`
--
ALTER TABLE `shopyfy_imports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `skus`
--
ALTER TABLE `skus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`) USING BTREE;

--
-- Indexes for table `skus_org`
--
ALTER TABLE `skus_org`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sku_product_id_idx` (`product_id`);

--
-- Indexes for table `skus_org2`
--
ALTER TABLE `skus_org2`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sku_product_id_idx` (`product_id`);

--
-- Indexes for table `sku_options`
--
ALTER TABLE `sku_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sku_option2sku_id_idx` (`sku_option2sku_id`),
  ADD KEY `sku_option2option_id_idx` (`sku_option2option_id`);

--
-- Indexes for table `stateprovs`
--
ALTER TABLE `stateprovs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `stateprov_country_id_idx` (`stateprov_country_id`);

--
-- Indexes for table `tax_groups`
--
ALTER TABLE `tax_groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tax_rates`
--
ALTER TABLE `tax_rates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tax_regions`
--
ALTER TABLE `tax_regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_users`
--
ALTER TABLE `admin_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2959;

--
-- AUTO_INCREMENT for table `category1`
--
ALTER TABLE `category1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `category2`
--
ALTER TABLE `category2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `config_groups`
--
ALTER TABLE `config_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `config_items`
--
ALTER TABLE `config_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=199;

--
-- AUTO_INCREMENT for table `credit_cards`
--
ALTER TABLE `credit_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `customer_stateproves`
--
ALTER TABLE `customer_stateproves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=606;

--
-- AUTO_INCREMENT for table `customer_types`
--
ALTER TABLE `customer_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cw_products`
--
ALTER TABLE `cw_products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=927;

--
-- AUTO_INCREMENT for table `discounts`
--
ALTER TABLE `discounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `discount_amounts`
--
ALTER TABLE `discount_amounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `discount_apply_types`
--
ALTER TABLE `discount_apply_types`
  MODIFY `discount_apply_type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `discount_categories`
--
ALTER TABLE `discount_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `discount_products`
--
ALTER TABLE `discount_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `discount_skuses`
--
ALTER TABLE `discount_skuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;

--
-- AUTO_INCREMENT for table `discount_types`
--
ALTER TABLE `discount_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `discount_usages`
--
ALTER TABLE `discount_usages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;

--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `image_types`
--
ALTER TABLE `image_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;

--
-- AUTO_INCREMENT for table `option_types`
--
ALTER TABLE `option_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `order_payments`
--
ALTER TABLE `order_payments`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `order_skuses`
--
ALTER TABLE `order_skuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=906;

--
-- AUTO_INCREMENT for table `order_sku_datas`
--
ALTER TABLE `order_sku_datas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_statuses`
--
ALTER TABLE `order_statuses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=927;

--
-- AUTO_INCREMENT for table `products2`
--
ALTER TABLE `products2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=927;

--
-- AUTO_INCREMENT for table `products_broken`
--
ALTER TABLE `products_broken`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=927;

--
-- AUTO_INCREMENT for table `products_no_cr`
--
ALTER TABLE `products_no_cr`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=927;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8540;

--
-- AUTO_INCREMENT for table `product_options`
--
ALTER TABLE `product_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2666;

--
-- AUTO_INCREMENT for table `product_upsells`
--
ALTER TABLE `product_upsells`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3227;

--
-- AUTO_INCREMENT for table `ship_methods`
--
ALTER TABLE `ship_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT for table `ship_method_countries`
--
ALTER TABLE `ship_method_countries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT for table `ship_ranges`
--
ALTER TABLE `ship_ranges`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `shopify_imports`
--
ALTER TABLE `shopify_imports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `shopyfy_imports`
--
ALTER TABLE `shopyfy_imports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `skus`
--
ALTER TABLE `skus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1156;

--
-- AUTO_INCREMENT for table `skus_org`
--
ALTER TABLE `skus_org`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1156;

--
-- AUTO_INCREMENT for table `skus_org2`
--
ALTER TABLE `skus_org2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1156;

--
-- AUTO_INCREMENT for table `sku_options`
--
ALTER TABLE `sku_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3239;

--
-- AUTO_INCREMENT for table `stateprovs`
--
ALTER TABLE `stateprovs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4216;

--
-- AUTO_INCREMENT for table `tax_groups`
--
ALTER TABLE `tax_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tax_rates`
--
ALTER TABLE `tax_rates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `tax_regions`
--
ALTER TABLE `tax_regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
