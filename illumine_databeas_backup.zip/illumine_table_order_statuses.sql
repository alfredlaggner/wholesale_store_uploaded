
-- --------------------------------------------------------

--
-- Table structure for table `order_statuses`
--

CREATE TABLE `order_statuses` (
  `id` int(11) NOT NULL,
  `shipstatus_name` varchar(70) DEFAULT NULL,
  `shipstatus_sort` float(11,3) DEFAULT '1.000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_statuses`
--

INSERT INTO `order_statuses` (`id`, `shipstatus_name`, `shipstatus_sort`, `created_at`, `updated_at`) VALUES
(1, 'Pending', 1.000, NULL, NULL),
(2, 'Balance Due', 2.000, NULL, NULL),
(3, 'Paid in Full', 3.000, NULL, NULL),
(4, 'Shipped', 4.000, NULL, NULL),
(5, 'Cancelled', 5.000, NULL, NULL),
(6, 'Returned', 6.000, NULL, NULL);
