
-- --------------------------------------------------------

--
-- Table structure for table `order_sku_datas`
--

CREATE TABLE `order_sku_datas` (
  `id` int(11) NOT NULL,
  `data_sku_id` int(11) DEFAULT NULL,
  `data_cart_id` varchar(50) DEFAULT NULL,
  `data_content` text,
  `data_date_added` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
