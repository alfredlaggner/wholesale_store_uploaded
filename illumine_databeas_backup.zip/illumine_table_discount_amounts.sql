
-- --------------------------------------------------------

--
-- Table structure for table `discount_amounts`
--

CREATE TABLE `discount_amounts` (
  `id` int(11) NOT NULL,
  `discount_amount_discount_id` int(11) NOT NULL DEFAULT '0',
  `discount_amount_discount` decimal(20,4) NOT NULL DEFAULT '0.0000',
  `discount_amount_minimum_qty` int(11) DEFAULT NULL,
  `discount_amount_minimum_amount` decimal(20,4) DEFAULT NULL,
  `discount_amount_rate_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_amounts`
--

INSERT INTO `discount_amounts` (`id`, `discount_amount_discount_id`, `discount_amount_discount`, `discount_amount_minimum_qty`, `discount_amount_minimum_amount`, `discount_amount_rate_type`, `created_at`, `updated_at`) VALUES
(35, 64, '10.0000', 0, '0.0000', '0', NULL, NULL),
(36, 65, '15.0000', 0, '0.0000', '0', NULL, NULL),
(37, 66, '10.0000', 0, '0.0000', '0', NULL, NULL);
