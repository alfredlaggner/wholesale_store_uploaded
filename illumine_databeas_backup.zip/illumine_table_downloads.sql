
-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` int(12) NOT NULL,
  `dl_sku_id` int(12) DEFAULT NULL,
  `dl_customer_id` varchar(255) DEFAULT NULL,
  `dl_timestamp` datetime DEFAULT NULL,
  `dl_file` varchar(255) DEFAULT NULL,
  `dl_version` varchar(255) DEFAULT NULL,
  `dl_remote_addr` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
