
-- --------------------------------------------------------

--
-- Table structure for table `ship_methods`
--

CREATE TABLE `ship_methods` (
  `id` int(11) NOT NULL,
  `ship_method_name` varchar(100) NOT NULL DEFAULT '',
  `ship_method_rate` double DEFAULT NULL,
  `ship_method_sort` float(11,3) NOT NULL DEFAULT '1.000',
  `ship_method_archive` smallint(6) DEFAULT '0',
  `ship_method_calctype` varchar(55) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ship_methods`
--

INSERT INTO `ship_methods` (`id`, `ship_method_name`, `ship_method_rate`, `ship_method_sort`, `ship_method_archive`, `ship_method_calctype`, `created_at`, `updated_at`) VALUES
(149, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(150, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(151, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(152, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(79, 'USPS', 0, 1.000, 0, 'localcalc', NULL, NULL),
(125, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(126, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(127, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(142, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(129, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(130, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(131, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(132, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(133, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(134, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(135, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(136, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(137, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(138, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(139, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(140, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(141, 'International Priority', 0, 0.000, 0, 'localcalc', NULL, NULL),
(144, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(145, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(146, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(147, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(148, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(153, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(154, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(155, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(156, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(157, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(158, 'International First Class', 0, 0.000, 0, 'localcalc', NULL, NULL),
(159, 'Wholesale Customers Only', 0, 0.000, 1, 'localcalc', NULL, NULL);
