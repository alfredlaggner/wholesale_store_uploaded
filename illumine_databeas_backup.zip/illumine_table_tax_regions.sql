
-- --------------------------------------------------------

--
-- Table structure for table `tax_regions`
--

CREATE TABLE `tax_regions` (
  `id` int(11) NOT NULL,
  `tax_region_country_id` int(11) NOT NULL DEFAULT '0',
  `tax_region_state_id` int(11) NOT NULL DEFAULT '0',
  `tax_region_label` varchar(150) DEFAULT NULL,
  `tax_region_tax_id` varchar(50) DEFAULT NULL,
  `tax_region_show_id` tinyint(4) DEFAULT NULL,
  `tax_region_ship_tax_method` varchar(50) DEFAULT NULL,
  `tax_region_ship_tax_group_id` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tax_regions`
--

INSERT INTO `tax_regions` (`id`, `tax_region_country_id`, `tax_region_state_id`, `tax_region_label`, `tax_region_tax_id`, `tax_region_show_id`, `tax_region_ship_tax_method`, `tax_region_ship_tax_group_id`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 'US Tax', '', 0, 'Highest Item Taxed', 0, NULL, NULL),
(4, 3, 51, 'PST', '', 0, 'No Tax', 0, NULL, NULL),
(6, 5, 0, 'VAT', '1', 0, 'Highest Item Taxed', 0, NULL, NULL),
(7, 3, 56, 'No Tax', '2', 0, 'Highest Item Taxed', 0, NULL, NULL),
(9, 6, 0, 'Test123', '12345', 1, 'Highest Item Taxed', 0, NULL, NULL),
(12, 198, 0, 'standard vat', '', 0, 'Tax Group', 5, NULL, NULL);
