
-- --------------------------------------------------------

--
-- Table structure for table `discount_skuses`
--

CREATE TABLE `discount_skuses` (
  `id` int(11) NOT NULL,
  `discount2sku_discount_id` int(11) NOT NULL DEFAULT '0',
  `discount2sku_sku_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
