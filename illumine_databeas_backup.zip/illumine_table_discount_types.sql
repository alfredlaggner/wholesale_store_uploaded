
-- --------------------------------------------------------

--
-- Table structure for table `discount_types`
--

CREATE TABLE `discount_types` (
  `id` int(11) NOT NULL,
  `discount_type` varchar(100) DEFAULT NULL,
  `discount_type_description` varchar(100) DEFAULT NULL,
  `discount_type_archive` tinyint(1) DEFAULT '0',
  `discount_type_order` int(2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_types`
--

INSERT INTO `discount_types` (`id`, `discount_type`, `discount_type_description`, `discount_type_archive`, `discount_type_order`, `created_at`, `updated_at`) VALUES
(1, 'sku_cost', 'Product/SKU Price', 0, 10, NULL, NULL),
(2, 'sku_ship', 'Product/SKU Shipping', 0, 20, NULL, NULL),
(3, 'order_total', 'Order Total', 0, 30, NULL, NULL),
(4, 'ship_total', 'Shipping Total', 0, 40, NULL, NULL);
