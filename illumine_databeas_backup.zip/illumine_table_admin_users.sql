
-- --------------------------------------------------------

--
-- Table structure for table `admin_users`
--

CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL,
  `admin_user_alias` varchar(255) DEFAULT NULL,
  `admin_username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `admin_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `admin_access_level` varchar(255) DEFAULT NULL,
  `admin_login_date` datetime DEFAULT NULL,
  `admin_last_login` datetime DEFAULT NULL,
  `admin_user_email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin_users`
--

INSERT INTO `admin_users` (`id`, `admin_user_alias`, `admin_username`, `admin_password`, `admin_access_level`, `admin_login_date`, `admin_last_login`, `admin_user_email`, `created_at`, `updated_at`) VALUES
(1, 'Developer', 'developer', '9tester9', 'developer', '2016-12-05 12:43:54', '2016-02-21 11:21:28', 'alexismasters@gmail.com', NULL, NULL),
(4, 'Merchant', 'merchant', 'tanya1618', 'merchant', '2017-11-02 18:22:38', '2017-11-01 18:46:46', 'info@illuminearts.com', NULL, NULL);
