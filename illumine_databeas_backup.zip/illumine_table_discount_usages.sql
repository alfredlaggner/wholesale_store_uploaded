
-- --------------------------------------------------------

--
-- Table structure for table `discount_usages`
--

CREATE TABLE `discount_usages` (
  `id` int(11) NOT NULL,
  `discount_usage_customer_id` varchar(50) DEFAULT NULL,
  `discount_usage_datetime` datetime DEFAULT NULL,
  `discount_usage_order_id` varchar(50) DEFAULT NULL,
  `discount_usage_discount_name` varchar(255) DEFAULT NULL,
  `discount_usage_discount_description` text,
  `discount_usage_promocode` varchar(255) DEFAULT NULL,
  `discount_usage_discount_id` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discount_usages`
--

INSERT INTO `discount_usages` (`id`, `discount_usage_customer_id`, `discount_usage_datetime`, `discount_usage_order_id`, `discount_usage_discount_name`, `discount_usage_discount_description`, `discount_usage_promocode`, `discount_usage_discount_id`, `created_at`, `updated_at`) VALUES
(94, 'F45A2F10-25-09', '2011-12-08 23:39:19', '1112082339-F45A', '', '', '', 84, NULL, NULL),
(95, 'F45A2F10-25-09', '2011-12-08 23:39:19', '1112082339-F45A', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(96, 'F45A2F10-25-09', '2011-12-08 23:39:19', '1112082339-F45A', 'Free Shipping', 'Free shipping on all items for the first 100 customers, when you spend $75 or more', 'FREESHIP', 70, NULL, NULL),
(97, '4416B4-131018', '2013-10-18 11:50:42', '1310181150-4416', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(101, 'F358E1-140423', '2014-04-23 18:59:23', '1404231859-F358', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(102, '8ACCF0-140825', '2014-08-25 12:06:29', '1408251206-8ACC', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(103, 'AD1C71-140429', '2014-09-24 14:06:33', '1409241406-AD1C', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(104, '470587-141007', '2014-10-10 02:15:23', '1410100215-4705', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(105, '914CBB-141103', '2014-11-03 12:59:34', '1411031259-914C', '10% Off over $100', 'Save 10 percent when you spend $100 or more', '', 71, NULL, NULL),
(106, '194559-140408', '2014-12-27 15:12:47', '1412271512-1945', 'Wholesale', '50% off for wholesale customers who have provided their resale numbers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(107, '87C55D-141227', '2014-12-27 17:28:59', '1412271728-87C5', 'Wholesale', '50% off for wholesale customers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(108, '6D99B8-150101', '2015-01-01 22:18:46', '1501012218-6D99', 'Wholesale', '50% off for wholesale customers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(109, '6D99B8-150101', '2015-01-02 20:49:02', '1501022049-6D99', 'Wholesale', '50% off for wholesale customers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(110, '0DE4D0-150105', '2015-01-05 21:32:07', '1501052132-0DE4', 'Wholesale', '50% off for wholesale customers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(111, '389DFA-150112', '2015-01-12 14:16:46', '1501121416-389D', 'Wholesale', '50% off for wholesale customers. A separate invoice will be issued for shipping charges when your order is processed.', '', 84, NULL, NULL),
(112, '7C1E7D-150317', '2015-03-17 11:38:04', '1503171138-7C1E', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(113, '7C1E7D-150317', '2015-03-17 11:38:04', '1503171138-7C1E', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(114, '6D99B8-150101', '2015-03-26 14:13:43', '1503261413-6D99', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(115, '6D99B8-150101', '2015-03-26 14:13:43', '1503261413-6D99', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(116, '6D99B8-150101', '2015-05-16 14:33:23', '1505161433-6D99', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(117, '6D99B8-150101', '2015-05-16 14:33:23', '1505161433-6D99', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(118, 'AD1C71-140429', '2015-07-22 15:52:26', '1507221552-AD1C', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(119, 'AD1C71-140429', '2015-07-22 15:52:26', '1507221552-AD1C', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(120, 'A842D4-150901', '2015-09-01 15:20:11', '1509011520-A842', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(121, 'A842D4-150901', '2015-09-01 15:20:11', '1509011520-A842', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(122, '6D99B8-150101', '2015-09-02 16:12:55', '1509021612-6D99', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(123, '6D99B8-150101', '2015-09-02 16:12:55', '1509021612-6D99', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(124, '389DFA-150112', '2015-09-14 23:11:40', '1509142311-389D', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(125, '389DFA-150112', '2015-09-14 23:11:40', '1509142311-389D', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(126, 'A8A134-150825', '2015-10-12 10:55:40', '1510121055-A8A1', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(127, 'A8A134-150825', '2015-10-12 10:55:40', '1510121055-A8A1', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(128, 'A8A134-150825', '2015-10-12 11:04:21', '1510121104-A8A1', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(129, 'A8A134-150825', '2015-10-12 11:04:21', '1510121104-A8A1', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(130, '109DC0-151008', '2015-11-29 23:42:55', '1511292342-109D', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(131, '109DC0-151008', '2015-11-29 23:42:55', '1511292342-109D', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(132, '0F2E3B-151204', '2015-12-09 19:33:09', '1512091933-0F2E', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(133, '0F2E3B-151204', '2015-12-09 19:33:09', '1512091933-0F2E', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(134, 'AD1C71-140429', '2016-01-09 18:18:38', '1601091818-AD1C', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(135, 'AD1C71-140429', '2016-01-09 18:18:38', '1601091818-AD1C', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(136, '109DC0-151008', '2016-03-09 20:15:52', '1603092015-109D', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(137, '109DC0-151008', '2016-03-09 20:15:52', '1603092015-109D', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(138, '0F2E3B-151204', '2016-06-16 11:31:53', '1606161131-0F2E', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(139, '0F2E3B-151204', '2016-06-16 11:31:53', '1606161131-0F2E', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(140, '2B137D-150611', '2016-06-24 14:23:06', '1606241423-2B13', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(141, '2B137D-150611', '2016-06-24 14:23:06', '1606241423-2B13', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(142, '2B137D-150611', '2016-08-21 13:35:26', '1608211335-2B13', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(143, '2B137D-150611', '2016-08-21 13:35:26', '1608211335-2B13', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(144, '2B137D-150611', '2017-03-05 12:55:17', '1703051255-2B13', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(145, '2B137D-150611', '2017-03-05 12:55:17', '1703051255-2B13', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(146, '0F2E3B-151204', '2017-04-07 09:28:05', '1704070928-0F2E', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(147, '0F2E3B-151204', '2017-04-07 09:28:05', '1704070928-0F2E', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(148, 'AD1C71-140429', '2017-07-21 17:15:00', '1707211715-AD1C', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(149, 'AD1C71-140429', '2017-07-21 17:15:00', '1707211715-AD1C', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(150, 'F84AA7-170725', '2017-07-25 14:58:42', '1707251458-F84A', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(151, 'F84AA7-170725', '2017-07-25 14:58:42', '1707251458-F84A', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(152, '2B137D-150611', '2017-10-03 18:00:45', '1710031800-2B13', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(153, '2B137D-150611', '2017-10-03 18:00:45', '1710031800-2B13', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL),
(154, '0F2E3B-151204', '2017-10-26 22:58:12', '1710262258-0F2E', 'Wholesale', '50% off for wholesale customers. ', '', 84, NULL, NULL),
(155, '0F2E3B-151204', '2017-10-26 22:58:12', '1710262258-0F2E', 'Wholesale Shipping', 'Shipping charges will be calculated and emailed in a followup invoice.', '', 85, NULL, NULL);
