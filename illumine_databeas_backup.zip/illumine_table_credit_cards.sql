
-- --------------------------------------------------------

--
-- Table structure for table `credit_cards`
--

CREATE TABLE `credit_cards` (
  `id` int(11) NOT NULL,
  `creditcard_name` varchar(50) DEFAULT NULL,
  `creditcard_code` varchar(50) DEFAULT NULL,
  `creditcard_archive` smallint(6) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `credit_cards`
--

INSERT INTO `credit_cards` (`id`, `creditcard_name`, `creditcard_code`, `creditcard_archive`, `created_at`, `updated_at`) VALUES
(2, 'MasterCard', 'mc', 0, NULL, NULL),
(4, 'Discover', 'disc', 0, NULL, NULL),
(18, 'Visa', 'visa', 0, NULL, NULL),
(21, 'Diners Club', 'diners', 0, NULL, NULL),
(24, 'Maestro', 'maestro', 0, NULL, NULL);
