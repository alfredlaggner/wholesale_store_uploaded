
-- --------------------------------------------------------

--
-- Table structure for table `category2`
--

CREATE TABLE `category2` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `archive` smallint(6) DEFAULT '0',
  `sort` float(11,3) DEFAULT '1.000',
  `description` text,
  `nav` smallint(6) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `category2`
--

INSERT INTO `category2` (`id`, `name`, `archive`, `sort`, `description`, `nav`, `created_at`, `updated_at`) VALUES
(3, 'Buddhist Cards', 0, 3.000, '', 1, NULL, NULL),
(101, 'Angel Prints', 0, 0.000, '', 1, NULL, NULL),
(4, 'Christian Cards', 0, 4.000, '', 1, NULL, NULL),
(9, 'Buddhist Prints', 0, 0.000, '', 1, NULL, NULL),
(10, 'Christian Prints', 0, 0.000, '', 1, NULL, NULL),
(11, 'Hindu Prints', 0, 0.000, '', 1, NULL, NULL),
(12, 'Other', 0, 0.000, '', 1, NULL, NULL),
(5, 'Hindu Cards', 0, 7.000, '', 1, NULL, NULL),
(1, 'Art Cards', 0, 2.000, '', 1, NULL, NULL),
(2, 'Angel Cards', 0, 1.000, '', 1, NULL, NULL),
(87, 'Mudra', 0, 0.000, '', 1, NULL, NULL),
(96, 'Message Cards', 0, 0.000, '', 1, NULL, NULL),
(90, 'Kuan Yin Cards', 0, 8.000, '', 1, NULL, NULL),
(92, 'Nature Cards', 0, 9.000, '', 1, NULL, NULL),
(97, 'Art Prints', 0, 0.000, '', 1, NULL, NULL),
(98, 'Ascending World Cards', 0, 0.000, '', 1, NULL, NULL);
