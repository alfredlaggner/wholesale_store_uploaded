
-- --------------------------------------------------------

--
-- Table structure for table `image_types`
--

CREATE TABLE `image_types` (
  `id` int(11) NOT NULL,
  `imagetype_name` varchar(100) DEFAULT NULL,
  `imagetype_sortorder` float(11,3) DEFAULT '1.000',
  `imagetype_folder` varchar(50) DEFAULT NULL,
  `imagetype_max_width` int(10) DEFAULT '0',
  `imagetype_max_height` int(10) DEFAULT '0',
  `imagetype_crop_width` int(10) DEFAULT '0',
  `imagetype_crop_height` int(10) DEFAULT '0',
  `imagetype_upload_group` int(2) DEFAULT '1',
  `imagetype_user_edit` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `image_types`
--

INSERT INTO `image_types` (`id`, `imagetype_name`, `imagetype_sortorder`, `imagetype_folder`, `imagetype_max_width`, `imagetype_max_height`, `imagetype_crop_width`, `imagetype_crop_height`, `imagetype_upload_group`, `imagetype_user_edit`, `created_at`, `updated_at`) VALUES
(1, 'Listings Thumbnail', 1.000, 'product_thumb', 110, 142, NULL, NULL, 1, 1, NULL, NULL),
(2, 'Details Main Image', 2.000, 'product_full', 300, 388, NULL, NULL, 1, 1, NULL, NULL),
(3, 'Details Zoom Image', 3.000, 'product_expanded', 600, 776, NULL, NULL, 1, 1, NULL, NULL),
(4, 'Cart Thumbnail', 4.000, 'product_small', 60, 78, NULL, NULL, 1, 1, NULL, NULL),
(5, 'SquareThumb', 5.000, 'product_thumb_square', 160, 160, NULL, NULL, 1, 0, NULL, NULL),
(6, 'Details Thumbnail', 6.000, 'product_thumb_details', 130, 168, NULL, NULL, 1, 1, NULL, NULL),
(7, 'Listings Thumbnail', 1.000, 'product_thumb', 130, 168, NULL, NULL, 2, 1, NULL, NULL),
(8, 'Details Main Image', 2.000, 'product_full', 300, 388, NULL, NULL, 2, 1, NULL, NULL),
(9, 'Details Zoom Image', 3.000, 'product_expanded', 600, 776, NULL, NULL, 2, 1, NULL, NULL),
(10, 'Cart Thumbnail', 4.000, 'product_small', 60, 78, NULL, NULL, 2, 1, NULL, NULL),
(11, 'SquareThumb', 5.000, 'product_thumb_square', 160, 160, NULL, NULL, 2, 0, NULL, NULL),
(12, 'Details Thumbnail', 6.000, 'product_thumb_details', 110, 142, NULL, NULL, 2, 1, NULL, NULL);
