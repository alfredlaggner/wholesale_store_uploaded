
-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

CREATE TABLE `discounts` (
  `id` int(11) NOT NULL,
  `discount_merchant_id` varchar(50) DEFAULT NULL,
  `discount_name` varchar(100) DEFAULT NULL,
  `discount_amount` float(12,2) DEFAULT NULL,
  `discount_calc` varchar(99) DEFAULT NULL,
  `discount_description` text,
  `discount_show_description` tinyint(1) DEFAULT '1',
  `discount_type` varchar(55) DEFAULT NULL,
  `discount_promotional_code` varchar(255) DEFAULT NULL,
  `discount_start_date` datetime DEFAULT NULL,
  `discount_end_date` datetime DEFAULT NULL,
  `discount_limit` int(11) DEFAULT '0',
  `discount_customer_limit` int(11) DEFAULT '0',
  `discount_global` tinyint(1) DEFAULT NULL,
  `discount_exclusive` tinyint(1) DEFAULT '0',
  `discount_priority` bigint(11) DEFAULT '0',
  `discount_archive` tinyint(4) DEFAULT '0',
  `discount_filter_customer_type` tinyint(1) DEFAULT '0',
  `discount_customer_type` varchar(100) DEFAULT NULL,
  `discount_filter_customer_id` tinyint(1) DEFAULT '0',
  `discount_customer_id` text,
  `discount_filter_cart_total` tinyint(1) DEFAULT '0',
  `discount_cart_total_max` float(12,2) DEFAULT '0.00',
  `discount_cart_total_min` float(12,2) DEFAULT '0.00',
  `discount_filter_item_qty` tinyint(1) DEFAULT '0',
  `discount_item_qty_min` int(8) DEFAULT '0',
  `discount_item_qty_max` int(8) DEFAULT '0',
  `discount_filter_cart_qty` tinyint(1) DEFAULT '0',
  `discount_cart_qty_min` int(8) DEFAULT '0',
  `discount_cart_qty_max` int(8) DEFAULT '0',
  `discount_association_method` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `discount_merchant_id`, `discount_name`, `discount_amount`, `discount_calc`, `discount_description`, `discount_show_description`, `discount_type`, `discount_promotional_code`, `discount_start_date`, `discount_end_date`, `discount_limit`, `discount_customer_limit`, `discount_global`, `discount_exclusive`, `discount_priority`, `discount_archive`, `discount_filter_customer_type`, `discount_customer_type`, `discount_filter_customer_id`, `discount_customer_id`, `discount_filter_cart_total`, `discount_cart_total_max`, `discount_cart_total_min`, `discount_filter_item_qty`, `discount_item_qty_min`, `discount_item_qty_max`, `discount_filter_cart_qty`, `discount_cart_qty_min`, `discount_cart_qty_max`, `discount_association_method`, `created_at`, `updated_at`) VALUES
(64, 'save10-spring sale', 'Save $10 when you spend $100 or more', 22.34, 'fixed', 'This is a great discount. Don\'t miss out!', 1, 'sku_cost', 'SAVE10', '2011-06-02 00:00:00', '2011-06-16 00:00:00', 0, 1, 1, NULL, NULL, 1, 0, NULL, 0, NULL, 0, 0.00, 0.00, 0, NULL, NULL, 0, 0, 0, 'products', NULL, NULL),
(66, 'GlobalDiscount001', 'Global Discount', 10.00, 'percent', '10% OFF everything!', 1, 'sku_cost', '1010', '2006-11-03 00:00:00', NULL, 0, 0, 1, 0, 1, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(71, 'Save10', '10% Off over $100', 10.00, 'percent', 'Save 10 percent when you spend $100 or more', 1, 'order_total', NULL, '2011-06-02 00:00:00', NULL, 0, 0, 1, 1, 5, 1, 0, '0', 0, NULL, 1, 1000.00, 100.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(73, 'summerFreeShipCategories', 'Free Shipping on all Clothing and Electronics', 100.00, 'percent', 'Get Free Shipping on all Clothing and Electronics items for a limited time!', 1, 'sku_ship', NULL, '2011-06-03 00:00:00', NULL, 0, 0, 0, 1, 10, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'categories', NULL, NULL),
(77, 'GlobalDiscount002', 'Global Ship Discount', 100.00, 'percent', 'Free shipping', 1, 'sku_ship', NULL, '2011-07-18 00:00:00', NULL, 0, 0, 1, 0, 0, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(78, '50off', '$50 OFF', 50.00, 'fixed', 'save $50 on any order', 1, 'order_total', '5050', '2011-03-01 00:00:00', '2011-03-30 00:00:00', 0, 0, 1, 0, 0, 1, 0, '0', 0, NULL, 0, 0.00, 860.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(79, 'GlobalDiscount003', 'Global Discount 25% all orders', 25.00, 'percent', '25% off all orders', 1, 'sku_cost', NULL, '2011-07-19 00:00:00', NULL, 0, 0, 1, 0, 0, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(80, '20OFFShipping', '$20 off shipping', 20.00, 'fixed', 'Save up to $20 on shipping', 1, 'ship_total', 'ship20', '2011-07-21 00:00:00', NULL, 0, 0, 1, 0, 0, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(82, 'QuantityDiscount', 'Quantity Discount', 10.00, 'percent', 'Get discount if you buy 2 or more.', 1, 'sku_cost', NULL, '2011-08-16 00:00:00', NULL, 0, 0, 0, 0, 0, 1, 0, '0', 0, NULL, 0, 0.00, 0.00, 1, 2, 0, 0, 0, 0, 'products', NULL, NULL),
(83, 'CustTypeDiscount', 'Wholesale Discount', 10.00, 'percent', 'Discount placed on products for Wholesale Customers', 0, 'sku_cost', NULL, '2011-09-12 00:00:00', NULL, 0, 0, 1, 0, 0, 1, 0, '2', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(84, 'Whsle', 'Wholesale', 50.00, 'percent', '50% off for wholesale customers. ', 1, 'sku_cost', NULL, '2013-03-28 00:00:00', NULL, 0, 0, 1, 0, 1, 0, 1, '2', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'products', NULL, NULL),
(85, 'Whsle Shipping', 'Wholesale Shipping', 100.00, 'percent', 'Shipping charges will be calculated and emailed in a followup invoice.', 1, 'ship_total', NULL, '2015-03-11 00:00:00', NULL, 0, 0, 1, 0, 2, 0, 1, '2', 0, NULL, 0, 0.00, 0.00, 0, 0, 0, 0, 0, 0, 'skus', NULL, NULL);
