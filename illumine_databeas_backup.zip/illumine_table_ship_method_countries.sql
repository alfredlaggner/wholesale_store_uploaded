
-- --------------------------------------------------------

--
-- Table structure for table `ship_method_countries`
--

CREATE TABLE `ship_method_countries` (
  `id` int(11) NOT NULL,
  `ship_method_country_method_id` int(11) DEFAULT '0',
  `ship_method_country_country_id` int(11) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ship_method_countries`
--

INSERT INTO `ship_method_countries` (`id`, `ship_method_country_method_id`, `ship_method_country_country_id`, `created_at`, `updated_at`) VALUES
(1, 35, 1, NULL, NULL),
(4, 76, 2, NULL, NULL),
(7, 65, 3, NULL, NULL),
(9, 74, 5, NULL, NULL),
(30, 96, 5, NULL, NULL),
(13, 79, 1, NULL, NULL),
(16, 82, 2, NULL, NULL),
(34, 100, 12, NULL, NULL),
(32, 98, 1, NULL, NULL),
(33, 99, 1, NULL, NULL),
(35, 101, 1, NULL, NULL),
(36, 102, 1, NULL, NULL),
(37, 103, 1, NULL, NULL),
(38, 104, 1, NULL, NULL),
(39, 105, 1, NULL, NULL),
(41, 107, 45, NULL, NULL),
(42, 108, 45, NULL, NULL),
(43, 109, 45, NULL, NULL),
(44, 110, 21, NULL, NULL),
(45, 111, 23, NULL, NULL),
(46, 112, 7, NULL, NULL),
(47, 113, 38, NULL, NULL),
(48, 114, 45, NULL, NULL),
(49, 115, 51, NULL, NULL),
(50, 116, 75, NULL, NULL),
(51, 117, 80, NULL, NULL),
(52, 118, 97, NULL, NULL),
(53, 119, 98, NULL, NULL),
(54, 120, 100, NULL, NULL),
(55, 121, 127, NULL, NULL),
(56, 122, 139, NULL, NULL),
(57, 123, 175, NULL, NULL),
(58, 124, 198, NULL, NULL),
(59, 125, 21, NULL, NULL),
(60, 126, 23, NULL, NULL),
(61, 127, 7, NULL, NULL),
(76, 142, 21, NULL, NULL),
(63, 129, 38, NULL, NULL),
(64, 130, 45, NULL, NULL),
(65, 131, 51, NULL, NULL),
(66, 132, 75, NULL, NULL),
(67, 133, 80, NULL, NULL),
(68, 134, 96, NULL, NULL),
(69, 135, 97, NULL, NULL),
(70, 136, 98, NULL, NULL),
(71, 137, 100, NULL, NULL),
(72, 138, 127, NULL, NULL),
(73, 139, 139, NULL, NULL),
(74, 140, 175, NULL, NULL),
(75, 141, 198, NULL, NULL),
(78, 144, 23, NULL, NULL),
(79, 145, 7, NULL, NULL),
(80, 146, 45, NULL, NULL),
(81, 147, 51, NULL, NULL),
(82, 148, 75, NULL, NULL),
(83, 149, 80, NULL, NULL),
(84, 150, 96, NULL, NULL),
(85, 151, 97, NULL, NULL),
(86, 152, 98, NULL, NULL),
(87, 153, 100, NULL, NULL),
(88, 154, 127, NULL, NULL),
(89, 155, 139, NULL, NULL),
(90, 156, 175, NULL, NULL),
(91, 157, 198, NULL, NULL),
(92, 158, 38, NULL, NULL),
(93, 159, 1, NULL, NULL);
