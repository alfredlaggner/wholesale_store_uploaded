
-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `option_type_id` int(11) DEFAULT '0',
  `option_name` varchar(50) DEFAULT NULL,
  `option_sort` float(11,3) DEFAULT '1.000',
  `option_archive` smallint(6) DEFAULT '0',
  `option_text` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `option_type_id`, `option_name`, `option_sort`, `option_archive`, `option_text`, `created_at`, `updated_at`) VALUES
(3, 2, '8.5 x 11', 1.000, 0, '', NULL, NULL),
(4, 2, '11 x 17', 2.000, 0, '', NULL, NULL);
